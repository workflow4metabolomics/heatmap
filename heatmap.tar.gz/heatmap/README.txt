## ****** heatmap environment: ****** ##
# version 1.1.0 (2015-05-30) E. Thevenot (CEA, MetaboHUB, W4M Core Development Team)

## --- PERL compilator / libraries : --- ##
NA
--

## --- R bin and Packages : --- ##
$ R --version
R version 3.0.1 (2013-05-16) -- "Good Sport"
Platform: x86_64-redhat-linux-gnu (64-bit)

The dependent libs are :
NA
-- 

## --- Binary dependencies --- ##
NA
--

## --- Config : --- ##
NA
--

## --- XML HELP PART --- ##
images:
heatmap_workflowPositionImage
heatmap_workingExampleImage
--

## --- DATASETS --- ##
No data set ! waiting for galaxy pages
--

## --- ??? COMMENTS ??? --- ##
CeCILL license
--